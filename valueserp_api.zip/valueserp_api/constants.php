<?php
define('API_URL', 'https://api.valueserp.com/');

?>